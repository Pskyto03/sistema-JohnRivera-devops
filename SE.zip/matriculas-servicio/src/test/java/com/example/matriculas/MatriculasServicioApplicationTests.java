/*
package com.example.matriculas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatriculasServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/
