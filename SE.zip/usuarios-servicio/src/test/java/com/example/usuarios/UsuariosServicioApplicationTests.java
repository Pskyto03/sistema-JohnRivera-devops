/*
package com.example.usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuariosServicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/
